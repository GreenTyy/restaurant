package com.example.restaurant.controller;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/admintor")
@CrossOrigin//支持跨域
public class AdminController {
    //adminInfo界面中,输出数据库admin表中的信息
}
