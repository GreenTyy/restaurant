package com.example.restaurant.domain;

public class Dishs {
    private String dishName;
    private String dishIntro;
    private int price;
}
