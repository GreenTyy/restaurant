package com.example.restaurant.controller;

public class LoginController {
       //登录控制器,对于数据库中的存在用户,响应adminInfo页面,对于未存在用户进行报错处理
}
