package com.example.restaurant.domain;

public class Admin {
    private int id;
    private String adminName;
    private String adminPwd;
    private String address;
    private String phone;
}
