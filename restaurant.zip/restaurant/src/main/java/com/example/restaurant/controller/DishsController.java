package com.example.restaurant.controller;

public class DishsController {
    //showDishs界面中,输出数据库dishs表中的信息
    //将修改后的信息挂载到数据库中
}
